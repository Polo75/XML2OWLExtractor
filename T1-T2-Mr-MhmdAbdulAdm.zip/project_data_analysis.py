from pprint import pprint as pp
import matplotlib.pyplot as plt


def getData():
    '''Fetch the data from source file and split the data line by line then put them in format of list of lists'''
    rawdata = open('c:/Users/mohd/OneDrive/Data Analysis Faouzi/data.txt').read()
    data = rawdata.split('\n')
    dataset = [word.split(';') for word in data]
    return dataset

def extractor(set):
    '''Extracted the data and store them in a dictionary [exData] in format of [Parent--> child--> occurrences] '''
    exData = {}
    for line in set:
        if len(line) > 1:
            key = line[3].replace("'", "")+'-'+line[2].replace("'", "")
            values = line[0].replace("'", '')
            exData.setdefault(key[6:],{}).setdefault(values,0)
            exData[key[6:]][values] = exData[key[6:]][values] + 1
    return exData

def enclose(exData):
    '''Store Parents and childs of parents in format : parent --> [child, child, ....] to used later to verfications'''
    parents = {}
    for item in exData:
        parent = item[4:]
        parents.setdefault(parent,[])

    for parent in parents:
        for item in exData:
            if item[4:] == parent:
                for child in exData[item]:
                    if child not in parents[parent]:
                        parents[parent].append(child)
    return parents

def counter(exData, parents):
    '''Return the final statistics result by take the extracted data from [exData] and compair the contents with [parents] data 
       to validate and count the maximam and minimam of occurrences of each child in each parent'''
    stateCounter = {}
    for parent in parents:
        for child in parents[parent]:
            for item in exData:
                if item[4:] == parent:
                    stateCounter.setdefault(parent,{}).setdefault(child, {'Max':0, 'Min':100})
                    if child in exData[item]:
                        pp(stateCounter)
                        if stateCounter[parent][child]['Max'] < exData[item][child]:
                            stateCounter[parent][child]['Max'] = exData[item][child]
                        if stateCounter[parent][child]['Min'] > exData[item][child]:
                            stateCounter[parent][child]['Min'] = exData[item][child]
                    else:
                        stateCounter[parent][child]['Min'] = 0
    return stateCounter

def main():
    exData = extractor(getData())
    parents = enclose(exData)
    finalResult = counter(exData, parents)
    pp(finalResult)



if __name__ == '__main__':
    main()